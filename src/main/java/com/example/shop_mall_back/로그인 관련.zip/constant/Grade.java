package com.example.shop_mall_back.common.constant;

public enum Grade {
    NORMAL,VIP,VVIP
}

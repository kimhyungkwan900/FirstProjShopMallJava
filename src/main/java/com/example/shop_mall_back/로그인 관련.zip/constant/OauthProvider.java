package com.example.shop_mall_back.common.constant;

public enum OauthProvider {
    LOCAL, GOOGLE, KAKAO, NAVER
}
package com.example.shop_mall_back.common.constant;

public enum LoginResult {
    SUCCESS,FAIL,TIMEOUT
}

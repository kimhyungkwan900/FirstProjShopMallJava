package com.example.shop_mall_back.common.constant;

public enum Role {
    MEMBER,ADMIN
}
